# Project repository

This repository contains all the components for your term project, which is to be done in groups. You will have one project for your group with two or three students having access to the repository.

For tips on collaborating with GitHub see the lesson and task on collaboration.

There is a separate folder for the proposal, the presentation, and the report. Within these folders there are templates for the components of your project with instructions. Please follow the pattern we used for the tasks and assignments: edit these files to complete the work for your project. Don't change the names of these files.

Please put the data you analyze in the data folder. You can use these data in all three components of the project.

There are are also files named starting with "grade" which I will use to assess each component of your project.

See the course detailed schedule for due dates for each component. 

